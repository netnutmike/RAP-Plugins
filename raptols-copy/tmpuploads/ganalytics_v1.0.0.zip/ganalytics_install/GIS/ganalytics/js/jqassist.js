if ( jQuery(document) )
	var $ = jQuery.noConflict();